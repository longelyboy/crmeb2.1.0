export default function(width=2,height=1){
	return width/height
}