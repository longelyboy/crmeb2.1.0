<template>
  <div class="goodList">
    <el-form
      size="small" inline label-width="150px"
    >
      <el-form-item label="商品分类：">
				 <el-select v-model="tableFrom.mer_cate_id" placeholder="请选择" class="filter-item selWidth mr20" clearable @change="getList(1)">
                <el-option v-for="item in merCateList" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>    
          </el-form-item>
          <el-form-item label="商品搜索：">
            <el-input
              placeholder="请输入商品名称,关键字,编号"
              v-model="tableFrom.keyword"
              style="width: 240px"
              @keyup.enter.native="getList(1)"
            >
            <el-button slot="append" icon="el-icon-search" class="el-button-solt" @click="getList(1)" />
          </el-input>
          </el-form-item>       
    </el-form>
    <el-table
      ref="table"  
      @selection-change="changeCheckbox"
      :data="tableData.data"
      v-loading="loading"
    >
    <el-table-column type="selection" width="55" />
      <el-table-column
        prop="product_id"
        label="商品id"
        min-width="200"
      />
     <el-table-column label="商品图" min-width="80">
        <template slot-scope="scope">
          <div class="demo-image__preview">
            <el-image
              style="width: 36px; height: 36px"
              :src="scope.row.image"
              :preview-src-list="[scope.row.image]"
            />
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="store_name"
        label="商品名称"
        min-width="200"
      />
    </el-table>
    <div class="acea-row row-right page">
      
       <el-pagination
          :page-sizes="[20, 40, 60, 80]"
          :page-size="tableFrom.limit"
          :current-page="tableFrom.page"
          layout="total, sizes, prev, pager, next, jumper"
          :total="tableData.total"
          @size-change="handleSizeChange"
          @current-change="pageChange"
        />
    </div>
    <div class="footer" slot="footer" v-if="many === 'many' && !diy">
      <el-button
        type="primary"
        size="large"
        :loading="modal_loading"
        style="width: 100%;"
        @click="ok"
        >提交</el-button
      >
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { categoryListApi, goodLstApi, categorySelectApi } from "@/api/product";

export default {
  name: "index",
  props: {
    is_new: {
      type: String,
      default: "",
    },
    diy: {
      type: Boolean,
      default: false,
    },
    isdiy: {
      type: Boolean,
      default: false,
    },
    ischeckbox: {
      type: Boolean,
      default: false,
    },
    liveStatus: {
      type: Boolean,
      default: false,
    },
    isLive: {
      type: Boolean,
      default: false,
    },
    datas: {
      type: Object,
      default: function () {
        return {};
      },
    },
  },
  data() {
    return {
			cateIds:[],
      merCateList: [], // 商户分类筛选
      modal_loading: false,
      treeSelect: [],
       props: {
        emitPath: false
      },
      tableFrom: {
        mer_cate_id: "",
        keyword: "",
        is_gift_bag: 0,
        page: 1,
        limit: 15,
        is_ficti:0
      },
      total: 0,
      modals: false,
      loading: false,
      tableData: {
        total: 0,
        data: []
      },
      currentid: 0,
      productRow: {},
      
      images: [],
      diyVal: [],
      many: "",
      idKey: "product_id",
      multipleSelectionAll: [],
      // multipleSelectionAll: window.form_create_helper.get(this.$route.query.field) || [],
      // idKey: "product_id",
    };
  },
  computed: {
    
  },
  created() {
    let radio = {
      width: 60,
      align: "center",
      render: (h, params) => {
        let id = params.row.id;
        let flag = false;
        if (this.currentid === id) {
          flag = true;
        } else {
          flag = false;
        }
        let self = this;
        return h("div", [
          h("Radio", {
            props: {
              value: flag,
            },
            on: {
              "on-change": () => {
                self.currentid = id;
                this.productRow = params.row;
                this.$emit("getProductId", this.productRow);
                if (this.productRow.id) {
                  if (this.$route.query.fodder === "image") {
                    /* eslint-disable */
                    let imageObject = {
                      image: this.productRow.image,
                      product_id: this.productRow.id,
                      name: this.productRow.name,
                    };
                    form_create_helper.set("image", imageObject);
                    form_create_helper.close("image");
                  }
                } else {
                  this.$message.warning("请先选择商品");
                }
              },
            },
          }),
        ]);
      },
    };

    let checkbox = {
      type: "selection",
      width: 60,
      align: "center",
    };
    let many = "";
    if (this.ischeckbox) {
      many = "many";
    } else {
      many = this.$route.query.type;
    }
    this.many = many;
    
  },
  mounted() {
    this.getCategorySelect();
    this.getList('');
    
  },
  methods: {
		handleSelectAll () {
		  this.$refs.table.selectAll(false);
		},
    changeCheckbox(selection) {
      let images = [];
      selection.forEach(function (item) {
        let imageObject = {
          image: item.image,
          product_id: item.product_id,
          store_name: item.store_name,
          temp_id: item.temp_id
        };
        images.push(imageObject);
      });
      this.images = images;
      this.diyVal = selection;
      this.$emit("getProductDiy", selection);
    },
    // 商品分类；
    goodsCategory() {
      categoryListApi(1)
        .then((res) => {
          this.treeSelect = res.data;
        })
        .catch((res) => {
          this.$message.error(res.message);
        });
    },
    // 商户分类；
    getCategorySelect() {
      categorySelectApi()
        .then(res => {
          this.merCateList = res.data
        })
        .catch(res => {
          this.$message.error(res.message)
        })
    },
     pageChange(page) {
      this.tableFrom.page = page
      this.getList('')
    },
    handleSizeChange(val) {
      this.tableFrom.limit = val
      this.getList('')
    },
    // 列表
    getList(num) {
      let that = this
      that.loading = true;
      that.tableFrom.page = num ? num : that.tableFrom.page
        goodLstApi(that.tableFrom)
          .then(async (res) => { 
            that.tableData.data = res.data.list;
            that.tableData.total = res.data.count;
            that.$nextTick(function () {
             that.setSelectRow(); //调用跨页选中方法
            });
            that.loading = false;
          })
          .catch((res) => {
            that.loading = false;
            that.$message.error(res.message);
          });
      
      
    },
   // 设置选中的方法
    setSelectRow() {
      if (!this.multipleSelectionAll || this.multipleSelectionAll.length <= 0) {
        return;
      }
      // 标识当前行的唯一键的名称
      let idKey = this.idKey;
      let selectAllIds = [];
      this.multipleSelectionAll.forEach((row) => {
        selectAllIds.push(row[idKey]);
      });
      this.$refs.table.clearSelection();
      for (var i = 0; i < this.tableData.data.length; i++) {
        if (selectAllIds.indexOf(this.tableData.data[i][idKey]) >= 0) {
          // 设置选中，记住table组件需要使用ref="table"
          this.$refs.table.toggleRowSelection(this.tableData.data[i], true);
        }
      }
    },
    ok() {
      if (this.images.length > 0) {
        if (this.$route.query.fodder === "image") {
          let imageValue = form_create_helper.get("image");
          form_create_helper.set("image", imageValue.concat(this.images));
          form_create_helper.close("image");
        } else {
          if(this.isdiy){
            this.$emit("getProductId", this.diyVal);
          }else {
            this.$emit("getProductId", this.images);
          }
        }
      } else {
        this.$message.warning("请先选择商品");
      }
    },
		treeSearchs(value){
			this.cateIds = value;
			this.tableFrom.page = 1;
			this.getList('');
		},
		// 表格搜索
    userSearchs() {
      this.tableFrom.page = 1;
      this.getList('');
    },
    clear() {
      this.productRow.id = "";
      this.currentid = "";
    },
  },
};
</script>

<style scoped lang="scss">
.footer {
  margin: 15px 0;
}

.tabBox_img {
  width: 36px;
  height: 36px;
  border-radius: 4px;
  cursor: pointer;

  img {
    width: 100%;
    height: 100%;
  }
}

.tabform {
   .ivu-form-item {
    margin-bottom: 16px !important;
  }
}

.btn {
  margin-top: 20px;
  float: right;
}

.goodList {
   table {
    width: 100% !important;
  }
}
</style>
