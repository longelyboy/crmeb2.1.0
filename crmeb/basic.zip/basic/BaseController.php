<?php
declare (strict_types=1);

namespace crmeb\basic;

use app\Request;
use crmeb\services\HttpService;
use RuntimeException;
use think\App;
use think\exception\ValidateException;
use think\Validate;

/**
 * 控制器基础类
 */
abstract class BaseController
{
    /**
     * Request实例
     * @var Request
     */
    protected $request;

    /**
     * 应用实例
     * @var \think\App
     */
    protected $app;

    /**
     * 是否批量验证
     * @var bool
     */
    protected $batchValidate = false;

    /**
     * 通过header token获取 admin 信息
     * @var bool
     */
    protected $adminInfo = [];

    /**
     * 控制器中间件
     * @var array
     */
    protected $middleware = [];

    private $authCode;

    /**
     * 构造方法
     * @access public
     * @param App $app 应用对象
     */
    public function __construct(App $app)
    {
        $this->app = $app;
        $this->request = $this->app->request;

        $rule = $this->request->rule()->getName();
        if (in_array($rule, ['systemMerchantCreateForm', 'systemMerchantCreate', 'systemMerchantUpdateForm', 'systemMerchantUpdate'])) {
            try {
                $this->authorizationDecryptCrmeb();
            } catch (\Exception $e) {
               // throw new ValidateException('请先进行商业授权');
            }
        }
        // 控制器初始化
        $this->initialize();
    }

    // 初始化
    protected function initialize()
    {
    }

    /**
     * 验证数据
     * @access protected
     * @param array $data 数据
     * @param string|array $validate 验证器名或者验证规则数组
     * @param array $message 提示信息
     * @param bool $batch 是否批量验证
     * @return array|string|true
     * @throws ValidateException
     */
    protected function validate(array $data, $validate, array $message = [], bool $batch = false)
    {
        if (is_array($validate)) {
            $v = new Validate();
            $v->rule($validate);
        } else {
            if (strpos($validate, '.')) {
                // 支持场景
                [$validate, $scene] = explode('.', $validate);
            }
            $class = false !== strpos($validate, '\\') ? $validate : $this->app->parseClass('validate', $validate);
            $v = new $class();
            if (!empty($scene)) {
                $v->scene($scene);
            }
        }

        $v->message($message);

        // 是否批量验证
        if ($batch || $this->batchValidate) {
            $v->batch(true);
        }

        return $v->failException(true)->check($data);
    }

    /**
     * 设置分页数据
     * @access protected
     * @return array
     * @throws ValidateException
     */
    protected function getPage()
    {
        $res = $this->request->params([['page', 1], ['limit', 10]], true);
        $res[0] = max(intval($res[0]), 1);
        return $res;
    }


    /**
     * 验证授权
     */
    final protected function checkAuthDecrypt()
    {
        try {
            $res = $this->authorizationDecryptCrmeb(true);
            if ($res && is_array($res)) {
                [$domain, $recordCode, $installtime] = $res;
                $time = $installtime + (45 * 3600 * 24);
                if ($time < time()) {
                    return app('json')->success('您得授权已过期请及时前往CRMEB官方进行授权', ['auth' => false]);
                } else {
                    $nowTime = ($time - time()) / (3600 * 24);
                    return app('json')->success('您的授权证书还有' . (int)$nowTime . '天过期,请及时前往CRMEB官方进行授权认证!', ['auth' => false]);
                }
            } else if ($res === true) {
                return app('json')->success();
            } else {
                return app('json')->fail('授权文件读取错误');
            }
        } catch (RuntimeException $e) {
            return app('json')->fail($e->getMessage());
        }
    }

    /**
     * @return mixed
     */
    final protected function getAuth()
    {
        try {
            $res = $this->authorizationDecryptCrmeb(true);
        } catch (RuntimeException $e) {
            $res = false;
        }
        $defaultRecordCode = '00000000';
        if (($res && is_array($res)) || !$res) {
            [$domain, $recordCode, $installtime] = $res;
            $version = get_crmeb_version();

            $res = HttpService::postRequest('http://authorize.crmeb.net/api/auth_cert_query', [
                'domain_name' => $this->request->host(),
                'label' => 10,
                'version' => $version
            ]);
            $res = $res ? json_decode($res, true) : [];
            $status = $res['data']['status'] ?? -9;
            $time = $installtime + (45 * 3600 * 24);
            if ($time < time()) {
                $day = 0;
            } else {
                $day = (int)bcdiv((string)($time - time()), (string)(3600 * 24), 0);
            }
            switch ((int)$status) {
                case 1:
                    //审核成功
                    $authCode = $res['data']['auth_code'] ?? $defaultRecordCode;
                    $autoContent = $res['data']['auto_content'] ?? '';
                    file_put_contents(app()->getRootPath() . 'cert_crmeb.key', $autoContent . ',' . $authCode);
                    return app('json')->success(['status' => 1, 'authCode' => $authCode, 'day' => 0]);
                    break;
                case 2:
                    //审核失败
                    return app('json')->success(['status' => 2, 'day' => $day]);
                    break;
                case -1:
                    //没有提交
                    return app('json')->success(['status' => -1, 'day' => $day]);
                    break;
                case 0:
                    //待审核
                    return app('json')->success(['status' => 0, 'day' => $day]);
                    break;
                default:
                    return app('json')->success(['status' => -9, 'day' => $day]);
                    break;
            }
        } else if ($res === true) {
            return app('json')->success(['status' => 1, 'authCode' => $this->authCode, 'day' => 0]);
        } else {
            return app('json')->success(['status' => 0]);
        }
    }

    /**
     * 解析授权
     */
    final private function authorizationDecryptCrmeb(bool $bool = false)
    {
        $authorizationExtactPath = (app()->getRootPath() . 'cert_public.pam');
        $authorizationExtacttext = (app()->getRootPath() . 'cert_crmeb.key');
        if (!$authorizationExtactPath || !is_file($authorizationExtactPath)) {
            throw new RuntimeException('授权证书丢失', 42007);
        }
        if (!$authorizationExtacttext || !is_file($authorizationExtacttext)) {
            throw new RuntimeException('授权文件丢失', 42006);
        }
        if ($authorizationExtactPath && $authorizationExtacttext) {
            $publicDecrypt = function (string $data, string $publicKey) {
                $decrypted = '';
                $pu_key = openssl_pkey_get_public(file_get_contents($publicKey));
                $plainData = str_split(base64_decode($data), 128);
                foreach ($plainData as $chunk) {
                    $str = '';
                    $decryptionOk = openssl_public_decrypt($chunk, $str, $pu_key);
                    if ($decryptionOk === false) {
                        return false;
                    }
                    $decrypted .= $str;
                }
                return $decrypted;
            };
            $encryptStr = file_get_contents($authorizationExtacttext);
            if (!$encryptStr) {
                throw new RuntimeException('授权文件内容丢失', 42005);
            }
            $resArray = explode('==', $encryptStr);
            if (!is_array($resArray)) {
                throw new RuntimeException('授权文件有变动无法解析', 42008);
            } else {
                [$encryptStr, $recordCode] = explode(',', $encryptStr);
            }
            if (!isset($recordCode)) {
                $recordCode = '';
            }
            $data = $publicDecrypt($encryptStr, $authorizationExtactPath);
            if ($data) {
                $data = json_decode($data);
                $path = app()->getRootPath() . 'public' . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'install.lock';
                if (!is_file($path)) {
                    $path = app()->getRootPath() . 'install/install.lock';
                }
                if (!is_file($path)) {
                    throw new RuntimeException('授权文件丢失', 42010);
                }
                $installtime = @filectime($path);
                if (isset($data->domain) && isset($data->expire) && isset($data->version)) {
                    $res = ($installtime + $data->expire) >= time();
                    if ($res) {
                        if ($bool && $data->domain === '*') {
                            return [$data->domain, $recordCode, $installtime];
                        }
                        if ($data->domain === '*' || in_array(request()->host(), ['127.0.0.1', 'localhost'])) {
                            return true;
                        } else if ($data->domain === $this->request->host()) {
                            $this->authCode = $recordCode;
                            return true;
                        } else {
                            throw new RuntimeException('您的授权域名和访问域名不一致!', 42000);
                        }
                    } else {
                        throw new RuntimeException('您的授权已到期', 42001);
                    }
                }
            } else {
                throw new RuntimeException('授权文件有变动无法解析', 42003);
            }
        }
        throw new RuntimeException('授权失败', 42004);
    }
}
